package showroom.mobil;
import java.sql.*;

public class Pelanggan {

    static Object[][] getPelangganData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private int idPelanggan;
    private String nama;
    private String nik;
    private String noTelp;
    private String alamat;

    // Constructor
    public Pelanggan(int idPelanggan, String nama, String nik, String noTelp, String alamat) {
        this.idPelanggan = idPelanggan;
        this.nama = nama;
        this.nik = nik;
        this.noTelp = noTelp;
        this.alamat = alamat;
    }

    // Getter dan Setter
    public int getIdPelanggan() {
        return idPelanggan;
    }

    public void setIdPelanggan(int idPelanggan) {
        this.idPelanggan = idPelanggan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    // CRUD Operasi

    // Create
    public static void addPelanggan(Pelanggan pelanggan) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO pelanggan (nama, nik, notelp, alamat) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, pelanggan.getNama());
                stmt.setString(2, pelanggan.getNik());
                stmt.setString(3, pelanggan.getNoTelp());
                stmt.setString(4, pelanggan.getAlamat());
                stmt.executeUpdate();
                System.out.println("Pelanggan berhasil ditambahkan!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Read
    public static void getPelanggan() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM pelanggan";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("idpelanggan") + ", Nama: " + rs.getString("nama"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update
    public static void updatePelanggan(int id, String nama, String nik, String noTelp, String alamat) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE pelanggan SET nama = ?, nik = ?, notelp = ?, alamat = ? WHERE idpelanggan = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, nama);
                stmt.setString(2, nik);
                stmt.setString(3, noTelp);
                stmt.setString(4, alamat);
                stmt.setInt(5, id);
                stmt.executeUpdate();
                System.out.println("Pelanggan berhasil diupdate!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete
    public static void deletePelanggan(int id) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM pelanggan WHERE idpelanggan = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                stmt.executeUpdate();
                System.out.println("Pelanggan berhasil dihapus!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
