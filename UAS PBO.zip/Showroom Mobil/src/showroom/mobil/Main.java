package showroom.mobil;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("===== Menu =====");
            System.out.println("1. CRUD Pelanggan");
            System.out.println("2. CRUD Mobil");
            System.out.println("3. CRUD Penjualan");
            System.out.println("4. Exit");
            System.out.print("Pilih menu: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Clear buffer

            switch (choice) {
                case 1:  // CRUD Pelanggan
                    System.out.println("===== CRUD Pelanggan =====");
                    System.out.println("1. Tambah Pelanggan");
                    System.out.println("2. Tampilkan Pelanggan");
                    System.out.println("3. Update Pelanggan");
                    System.out.println("4. Hapus Pelanggan");
                    System.out.print("Pilih opsi: ");
                    int pelangganChoice = scanner.nextInt();
                    scanner.nextLine();  // Clear buffer

                    switch (pelangganChoice) {
                        case 1:
                            // Tambah Pelanggan
                            System.out.print("Nama: ");
                            String nama = scanner.nextLine();
                            System.out.print("NIK: ");
                            String nik = scanner.nextLine();
                            System.out.print("No Telp: ");
                            String noTelp = scanner.nextLine();
                            System.out.print("Alamat: ");
                            String alamat = scanner.nextLine();

                            Pelanggan pelanggan = new Pelanggan(0, nama, nik, noTelp, alamat);
                            Pelanggan.addPelanggan(pelanggan);
                            break;
                        case 2:
                            // Tampilkan Pelanggan
                            Pelanggan.getPelanggan();
                            break;
                        case 3:
                            // Update Pelanggan
                            System.out.print("ID Pelanggan yang ingin diupdate: ");
                            int idPelanggan = scanner.nextInt();
                            scanner.nextLine();  // Clear buffer
                            System.out.print("Nama Baru: ");
                            String namaBaru = scanner.nextLine();
                            System.out.print("NIK Baru: ");
                            String nikBaru = scanner.nextLine();
                            System.out.print("No Telp Baru: ");
                            String noTelpBaru = scanner.nextLine();
                            System.out.print("Alamat Baru: ");
                            String alamatBaru = scanner.nextLine();

                            Pelanggan.updatePelanggan(idPelanggan, namaBaru, nikBaru, noTelpBaru, alamatBaru);
                            break;
                        case 4:
                            // Hapus Pelanggan
                            System.out.print("ID Pelanggan yang ingin dihapus: ");
                            int deleteIdPelanggan = scanner.nextInt();
                            Pelanggan.deletePelanggan(deleteIdPelanggan);
                            break;
                        default:
                            System.out.println("Pilihan tidak valid.");
                    }
                    break;

                case 2:  // CRUD Mobil
                    // CRUD Mobil (Tambah, Tampilkan, Update, Hapus)
                    break;

                case 3:  // CRUD Penjualan
                    // CRUD Penjualan (Tambah, Tampilkan, Update, Hapus)
                    break;

                case 4:
                    System.out.println("Keluar dari aplikasi...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }
}
