package showroom.mobil;
public class penjualan {

    static Object[][] getpenjualanData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private int idPenjualan;
    private int idPelanggan;
    private int idMobil;
    private double totalBiaya;

    // Constructor
    public penjualan(int idPenjualan, int idPelanggan, int idMobil, double totalBiaya) {
        this.idPenjualan = idPenjualan;
        this.idPelanggan = idPelanggan;
        this.idMobil = idMobil;
        this.totalBiaya = totalBiaya;
    }

    void addPenjualan(penjualan penjualan) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


}
