package showroom.mobil;
public class Mobil {

    static void addMobil(Mobil mobil) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Object[][] getMobilData() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private int idMobil;
    private String merk;
    private int tahun;
    private double harga;

    // Constructor
    public Mobil(int idMobil, String merk, int tahun, double harga) {
        this.idMobil = idMobil;
        this.merk = merk;
        this.tahun = tahun;
        this.harga = harga;
    }


}
